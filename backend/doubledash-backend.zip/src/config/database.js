const AWS = require('aws-sdk');
require('dotenv').config();

// Configure AWS SDK
AWS.config.update({
  region: process.env.AWS_REGION || 'us-west-2',
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

// Create DynamoDB DocumentClient instance
const dynamoDB = new AWS.DynamoDB.DocumentClient();

// Test the connection
const testConnection = async () => {
  try {
    await dynamoDB.scan({
      TableName: 'Users',
      Limit: 1
    }).promise();
    console.log('✅ DynamoDB connection successful');
  } catch (error) {
    console.error('❌ DynamoDB connection failed:', error.message);
  }
};

module.exports = dynamoDB;
module.exports.testConnection = testConnection;